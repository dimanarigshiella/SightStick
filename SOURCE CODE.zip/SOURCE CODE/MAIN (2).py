
import threading
import time
import RPi.GPIO as GPIO
import pyttsx3
import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl
from ultralytics import YOLO
import cv2
from picamera2 import Picamera2


def cm_to_inch(cm):
    """Convert centimeters to inches."""
    return cm / 2.54

# Suppress GPIO warnings and set GPIO mode
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

# Define GPIO pins for three ultrasonic sensors
TRIG_PINS = [23, 20, 19]
ECHO_PINS = [24, 21, 26]

# Initialize pyttsx3 engine
engine = pyttsx3.init()

# Define fuzzy variables
leftUltrasonic = ctrl.Antecedent(np.arange(0, 401, 1), 'distance1')
frontUltrasonic = ctrl.Antecedent(np.arange(0, 401, 1), 'distance2')
rightUltrasonic = ctrl.Antecedent(np.arange(0, 401, 1), 'distance3')
navigation = ctrl.Consequent(np.arange(0, 6, 1), 'navigation')

# Define fuzzy membership functions using trapezoidal for "near" and "far"
for distance in [leftUltrasonic, frontUltrasonic, rightUltrasonic]:
    distance['near'] = fuzz.trapmf(distance.universe, [0, 0, 50, 100])
    distance['medium'] = fuzz.trimf(distance.universe, [55, 150, 250])
    distance['far'] = fuzz.trapmf(distance.universe, [200, 300, 400, 400])

# Define fuzzy membership functions for navigation
navigation['stop'] = fuzz.trimf(navigation.universe, [0, 0, 0.5])
navigation['turn_left'] = fuzz.trimf(navigation.universe, [0.5, 1, 1.5])
navigation['go_straight'] = fuzz.trimf(navigation.universe, [2.5, 3, 3.5])
navigation['turn_right'] = fuzz.trimf(navigation.universe, [4.5, 5, 5])

# Define fuzzy rules
rules = [
    ctrl.Rule(leftUltrasonic['near'] & frontUltrasonic['near'] & rightUltrasonic['near'], navigation['stop']),
    ctrl.Rule(leftUltrasonic['near'] & frontUltrasonic['near'] & rightUltrasonic['medium'], navigation['turn_right']),
    ctrl.Rule(leftUltrasonic['near'] & frontUltrasonic['near'] & rightUltrasonic['far'], navigation['turn_right']),
    ctrl.Rule(leftUltrasonic['near'] & frontUltrasonic['medium'] & rightUltrasonic['near'], navigation['go_straight']),
    ctrl.Rule(leftUltrasonic['near'] & frontUltrasonic['medium'] & rightUltrasonic['medium'], navigation['go_straight']),
    ctrl.Rule(leftUltrasonic['near'] & frontUltrasonic['far'] & rightUltrasonic['near'], navigation['go_straight']),
    ctrl.Rule(leftUltrasonic['near'] & frontUltrasonic['far'] & rightUltrasonic['medium'], navigation['go_straight']),
    ctrl.Rule(leftUltrasonic['near'] & frontUltrasonic['far'] & rightUltrasonic['far'], navigation['go_straight']),
    ctrl.Rule(leftUltrasonic['medium'] & frontUltrasonic['near'] & rightUltrasonic['near'], navigation['turn_left']),
    ctrl.Rule(leftUltrasonic['medium'] & frontUltrasonic['near'] & rightUltrasonic['medium'], navigation['stop']),
    ctrl.Rule(leftUltrasonic['medium'] & frontUltrasonic['near'] & rightUltrasonic['far'], navigation['turn_right']),
    ctrl.Rule(leftUltrasonic['medium'] & frontUltrasonic['medium'] & rightUltrasonic['near'], navigation['go_straight']),
    ctrl.Rule(leftUltrasonic['medium'] & frontUltrasonic['medium'] & rightUltrasonic['medium'], navigation['go_straight']),
    ctrl.Rule(leftUltrasonic['medium'] & frontUltrasonic['medium'] & rightUltrasonic['far'], navigation['turn_right']),
    ctrl.Rule(leftUltrasonic['medium'] & frontUltrasonic['far'] & rightUltrasonic['near'], navigation['go_straight']),
    ctrl.Rule(leftUltrasonic['medium'] & frontUltrasonic['far'] & rightUltrasonic['medium'], navigation['go_straight']),
    ctrl.Rule(leftUltrasonic['medium'] & frontUltrasonic['far'] & rightUltrasonic['far'], navigation['go_straight']),
    ctrl.Rule(leftUltrasonic['far'] & frontUltrasonic['far'] & rightUltrasonic['far'], navigation['go_straight']),
    ctrl.Rule(leftUltrasonic['far'] & frontUltrasonic['near'] & rightUltrasonic['near'], navigation['turn_left']),
    ctrl.Rule(leftUltrasonic['far'] & frontUltrasonic['near'] & rightUltrasonic['medium'], navigation['turn_left']),
    ctrl.Rule(leftUltrasonic['far'] & frontUltrasonic['medium'] & rightUltrasonic['near'], navigation['turn_left']),
    ctrl.Rule(leftUltrasonic['far'] & frontUltrasonic['medium'] & rightUltrasonic['medium'], navigation['turn_left']),
    ctrl.Rule(leftUltrasonic['far'] & frontUltrasonic['medium'] & rightUltrasonic['far'], navigation['go_straight']),
    ctrl.Rule(leftUltrasonic['far'] & frontUltrasonic['far'] & rightUltrasonic['near'], navigation['go_straight']),
    ctrl.Rule(leftUltrasonic['far'] & frontUltrasonic['far'] & rightUltrasonic['medium'], navigation['go_straight']),
    ctrl.Rule(leftUltrasonic['far'] & frontUltrasonic['near'] & rightUltrasonic['far'], navigation['stop']),
]

# Create and compile fuzzy control system
navigation_ctrl = ctrl.ControlSystem(rules)
navigation_system = ctrl.ControlSystemSimulation(navigation_ctrl)

# Set up GPIO pins for ultrasonic sensors
for trig, echo in zip(TRIG_PINS, ECHO_PINS):
    GPIO.setup(trig, GPIO.OUT)
    GPIO.setup(echo, GPIO.IN)
    GPIO.output(trig, False)

# Load YOLOv8 model
model = YOLO('/home/pi/best9.pt')  # Ensure the path is correct

# Initialize Picamera2
picam2 = Picamera2()
picam2.preview_configuration.main.size = (640, 640)  # Reduced resolution for speed
picam2.preview_configuration.main.format = "RGB888"
picam2.preview_configuration.align()
picam2.configure("preview")
picam2.start()

# Shared data structure for distances
distances = {'distance1': None, 'distance2': None, 'distance3': None}
dist_lock = threading.Lock()

# Flag to signal threads to stop
stop_flag = threading.Event()

def measure_distance(trig, echo, distance_key):
    """Measure distance using ultrasonic sensor."""
    while not stop_flag.is_set():
        GPIO.output(trig, False)
        time.sleep(0.05)  # Reduced stabilization delay

        GPIO.output(trig, True)
        time.sleep(0.00001)  # 10Ã‚Âµs pulse
        GPIO.output(trig, False)

        pulse_start = time.time()
        pulse_end = pulse_start

        # Wait for echo start
        while GPIO.input(echo) == 0:
            pulse_start = time.time()
            if pulse_start - pulse_end > 0.05:  # 50ms timeout
                pulse_start = None
                break

        if pulse_start is None:
            with dist_lock:
                distances[distance_key] = None
            continue

        # Wait for echo end
        while GPIO.input(echo) == 1:
            pulse_end = time.time()
            if pulse_end - pulse_start > 0.05:  # 50ms timeout
                pulse_end = None
                break

        if pulse_end is None:
            with dist_lock:
                distances[distance_key] = None
            continue

        pulse_duration = pulse_end - pulse_start
        distance = pulse_duration * 17150  # Convert to cm
        distance = round(distance, 2)
        distance = min(distance, 400)  # Cap at 400 cm

        with dist_lock:
            distances[distance_key] = distance

        time.sleep(0.05)  # 50ms between measurements

latest_frame = None
frame_lock = threading.Lock()

def capture_frames():
    """Continuously capture frames from the camera."""
    global latest_frame
    while not stop_flag.is_set():
        with frame_lock:
            latest_frame = picam2.capture_array()  # Capture the latest frame
        time.sleep(0.03)

def detect_objects(frame):
    """Perform object detection on the given frame and display results."""
    results = model(frame)
    detected_objects = []
    for result in results:
        for obj in result.boxes:
            if obj.conf > 0.60:
                detected_objects.append(obj)
    return detected_objects

def display_frame():
    """Display the latest frame in a separate window."""
    while not stop_flag.is_set():
        with frame_lock:
            frame = latest_frame

        if frame is not None:  # Check if the frame is captured
            cv2.imshow("Camera Feed", frame)
            cv2.waitKey(1)    

def navigation_control():
    """Compute navigation commands based on sensor distances and camera input."""
    while not stop_flag.is_set():
        with dist_lock:
            dist1 = distances['distance1']
            dist2 = distances['distance2']
            dist3 = distances['distance3']

        if dist1 is not None and dist2 is not None and dist3 is not None:
            try:
                # Set fuzzy inputs
                with frame_lock:
                    frame = latest_frame  

                if frame is not None:  
                    detected_objects = detect_objects(frame)

                navigation_system.input['distance1'] = dist1
                navigation_system.input['distance2'] = dist2
                navigation_system.input['distance3'] = dist3
                navigation_system.compute()
                nav_value = navigation_system.output['navigation']
                

                # Determine navigation action
                if nav_value < 1:
                    action = "stop"
                elif nav_value < 2:
                    action = "turn_left"
                elif nav_value < 4:
                    action = "go_straight"
                else:
                    action = "turn_right"

                tts_start_time = time.time()
                engine.say(action)
                engine.runAndWait()
                time.sleep(0.03)
                tts_time = time.time() - tts_start_time

                print("------------------------------")
                print(f"Distance 1: {dist1:.2f} cm")
                print(f"Distance 2: {dist2:.2f} cm")
                print(f"Distance 3: {dist3:.2f} cm")
                print(f"Navigation: {action}")
                print(f"Response Time: {tts_time:.4f} seconds")

                if detected_objects:
                    for obj in detected_objects:
                        bbox = obj.xyxy.numpy()[0]
                        class_id = int(obj.cls)  # Class of the object
                        label = model.names[class_id]
                        y_text = max(y1 - 10, 10)
                    
                        obj_center_x = (bbox[0] + bbox[2]) / 2
                        frame_center_x = frame.shape[1] / 2

                        if obj_center_x < frame_center_x - frame.shape[1] * 0.1:
                            position = "left"
                        elif obj_center_x > frame_center_x + frame.shape[1] * 0.1:
                            position = "right"
                        else:
                            position = "ahead"

                        confidence = obj.conf.item() * 100 


                        # Draw bounding box
                        x1, y1, x2, y2 = int(obj.xyxy[0][0]), int(obj.xyxy[0][1]), int(obj.xyxy[0][2]), int(obj.xyxy[0][3])

                        # Add label and confidence score
                        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2) 
                        text = f"{label} ({confidence:.2f}%)"
                        cv2.putText(frame, text, (x1, y_text), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

                        # Display the frame with bounding boxes and labels
                        cv2.imshow("Object Detection", frame)
                        cv2.waitKey(1) # Allows frame refresh; set to 1ms delay for real-time video


                        message = (f"{label} detected on the {position}, at distance approximately {cm_to_inch(dist2):.2f} inches.")  
                        engine.say(message)
                        engine.runAndWait()
            except Exception as e:
                print(f"Error in navigation control: {e}")

# Thread management for ultrasonic sensors
threads = []
for i, (trig, echo, dist_key) in enumerate(zip(TRIG_PINS, ECHO_PINS, ['distance1', 'distance2', 'distance3'])):
    t = threading.Thread(target=measure_distance, args=(trig, echo, dist_key))
    t.start()
    threads.append(t)

try:
    navigation_control()
finally:
    # Signal threads to stop
    stop_flag.set()

    # Wait for threads to finish
    for t in threads:
        t.join()
    
    picam2.stop()

    # Clean up GPIO
    GPIO.cleanup()


